import Vue from 'vue';
import ResponseCheck from './ResponseCheck';

new Vue({
  render: createElement => createElement(ResponseCheck)
}).$mount('#root');
